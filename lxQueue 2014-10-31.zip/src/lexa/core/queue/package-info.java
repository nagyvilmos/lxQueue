/**
 * Queue operations for Lexa.
 * @since 2013-05
 */
package lexa.core.queue;
